Sample: oceanFFT
Minimum spec: SM 3.0

This sample simulates an Ocean height field using CUFFT Library and renders the result using OpenGL.

Key concepts:
Graphics Interop
Image Processing
CUFFT Library

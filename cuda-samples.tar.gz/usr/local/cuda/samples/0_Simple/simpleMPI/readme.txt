Sample: simpleMPI
Minimum spec: SM 3.0

Simple example demonstrating how to use MPI in combination with CUDA.

Key concepts:
CUDA Systems Integration
MPI
Multithreading

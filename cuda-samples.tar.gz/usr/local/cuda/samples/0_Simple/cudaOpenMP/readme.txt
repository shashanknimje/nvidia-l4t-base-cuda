Sample: cudaOpenMP
Minimum spec: SM 3.0

This sample demonstrates how to use OpenMP API to write an application for multiple GPUs.

Key concepts:
CUDA Systems Integration
OpenMP
Multithreading

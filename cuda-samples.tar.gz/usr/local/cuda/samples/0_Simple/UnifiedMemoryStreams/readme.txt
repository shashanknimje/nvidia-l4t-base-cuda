Sample: UnifiedMemoryStreams
Minimum spec: SM 3.0

This sample demonstrates the use of OpenMP and streams with Unified Memory on a single GPU.

Key concepts:
CUDA Systems Integration
OpenMP
CUBLAS
Multithreading
Unified Memory
CUDA Streams and Events

Sample: asyncAPI
Minimum spec: SM 3.0

This sample uses CUDA streams and events to overlap execution on CPU and GPU.

Key concepts:
Asynchronous Data Transfers
CUDA Streams and Events

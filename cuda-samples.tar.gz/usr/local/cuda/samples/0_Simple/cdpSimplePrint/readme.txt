Sample: cdpSimplePrint
Minimum spec: SM 3.5

This sample demonstrates simple printf implemented using CUDA Dynamic Parallelism.  This sample requires devices with compute capability 3.5 or higher.

Key concepts:
CUDA Dynamic Parallelism

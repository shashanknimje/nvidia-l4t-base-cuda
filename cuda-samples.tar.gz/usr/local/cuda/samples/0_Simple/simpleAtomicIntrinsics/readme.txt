Sample: simpleAtomicIntrinsics
Minimum spec: SM 3.0

A simple demonstration of global memory atomic instructions.

Key concepts:
Atomic Intrinsics

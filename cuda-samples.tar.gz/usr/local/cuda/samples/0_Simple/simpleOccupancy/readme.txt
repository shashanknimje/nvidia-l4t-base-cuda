Sample: simpleOccupancy
Minimum spec: SM 3.0

This sample demonstrates the basic usage of the CUDA occupancy calculator and occupancy-based launch configurator APIs by launching a kernel with the launch configurator, and measures the utilization difference against a manually configured launch.

Key concepts:
Occupancy Calculator

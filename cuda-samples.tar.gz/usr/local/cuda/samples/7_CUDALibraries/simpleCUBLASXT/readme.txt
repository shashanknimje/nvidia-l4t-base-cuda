Sample: simpleCUBLASXT
Minimum spec: SM 3.0

Example of using CUBLAS-XT library.

Key concepts:
CUBLAS-XT Library

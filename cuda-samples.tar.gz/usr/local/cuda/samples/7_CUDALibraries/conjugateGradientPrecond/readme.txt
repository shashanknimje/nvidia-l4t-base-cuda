Sample: conjugateGradientPrecond
Minimum spec: SM 3.0

This sample implements a preconditioned conjugate gradient solver on GPU using CUBLAS and CUSPARSE library.

Key concepts:
Linear Algebra
CUBLAS Library
CUSPARSE Library

Sample: MC_SingleAsianOptionP
Minimum spec: SM 3.0

This sample uses Monte Carlo to simulate Single Asian Options using the NVIDIA CURAND library.

Key concepts:
Random Number Generator
Computational Finance
CURAND Library

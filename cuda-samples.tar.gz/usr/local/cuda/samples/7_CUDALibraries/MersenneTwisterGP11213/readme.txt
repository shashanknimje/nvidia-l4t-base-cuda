Sample: MersenneTwisterGP11213
Minimum spec: SM 3.0

This sample demonstrates the Mersenne Twister random number generator GP11213 in cuRAND.

Key concepts:
Computational Finance
CURAND Library

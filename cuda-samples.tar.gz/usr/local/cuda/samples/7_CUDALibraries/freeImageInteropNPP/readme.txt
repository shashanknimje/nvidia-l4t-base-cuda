Sample: freeImageInteropNPP
Minimum spec: SM 3.0

A simple CUDA Sample demonstrate how to use FreeImage library with NPP.

Key concepts:
Performance Strategies
Image Processing
NPP Library

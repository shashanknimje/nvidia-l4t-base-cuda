Sample: EGLStreams_CUDA_Interop
Minimum spec: SM 3.0

Demonstrates data exchange between CUDA and EGL Streams.

Key concepts:
EGLStreams Interop

Sample: postProcessGL
Minimum spec: SM 3.0

This sample shows how to post-process an image rendered in OpenGL using CUDA.

Key concepts:
Graphics Interop
Image Processing

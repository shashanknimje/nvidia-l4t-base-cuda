Sample: dwtHaar1D
Minimum spec: SM 3.0

Discrete Haar wavelet decomposition for 1D signals with a length which is a power of 2.

Key concepts:
Image Processing
Video Compression

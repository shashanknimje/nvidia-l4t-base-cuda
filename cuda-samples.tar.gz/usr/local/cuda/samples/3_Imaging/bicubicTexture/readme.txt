Sample: bicubicTexture
Minimum spec: SM 3.0

This sample demonstrates how to efficiently implement a Bicubic B-spline interpolation filter with CUDA texture.

Key concepts:
Graphics Interop
Image Processing

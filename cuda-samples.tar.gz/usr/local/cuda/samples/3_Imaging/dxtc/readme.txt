Sample: dxtc
Minimum spec: SM 3.0

High Quality DXT Compression using CUDA. This example shows how to implement an existing computationally-intensive CPU compression algorithm in parallel on the GPU, and obtain an order of magnitude performance improvement.

Key concepts:
Cooperative Groups
Image Processing
Image Compression

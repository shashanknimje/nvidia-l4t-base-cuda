Sample: SobolQRNG
Minimum spec: SM 3.0

This sample implements Sobol Quasirandom Sequence Generator.

Key concepts:
Computational Finance
